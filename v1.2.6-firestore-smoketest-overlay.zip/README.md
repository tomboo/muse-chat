# Muse Chat v1.2.6 Firestore Smoke Test Overlay

## Overview
Adds a simple in-app component to test Firestore connectivity and confirm read/write operations.

### Files Added
- `src/components/SmokeTest.tsx`

### Integration Steps
1. Copy the file into your `/src/components` directory.
2. Import and render it temporarily in your `App.tsx`:
   ```tsx
   import SmokeTest from "./components/SmokeTest";
   ...
   <SmokeTest /> {/* Place before <DebugPanel /> */}
   ```
3. Run your app:
   ```bash
   npm run dev
   ```
4. In your app window:
   - Click **Save** → writes default test settings to Firestore.
   - Click **Load** → retrieves those settings.
   - Click **Clear** → clears the on-screen log.

5. Watch the console:
   - You should see “Loaded data: { ... }”
   - Verify Firestore collection: `users/demo/config/settings`

### Removal
Once verified, remove the `<SmokeTest />` line from `App.tsx`.  
This component is purely for testing and introduces no side effects.

---
Muse Chat v1.2.6 © 2025
