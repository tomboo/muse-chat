import React, { useState } from "react";
import { saveSettings, loadSettings } from "../services/firestore";

/**
 * Firestore Smoke Test Component
 * Quick, safe test to verify read/write functionality and Firestore connectivity.
 */
const SmokeTest: React.FC = () => {
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async () => {
    try {
      setLoading(true);
      setError(null);
      await saveSettings({ theme: "dark", model: "mock", storage: "firestore" });
      setResult("✅ Saved to Firestore!");
    } catch (err: any) {
      console.error("Save failed:", err);
      setError("❌ Save failed: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLoad = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await loadSettings();
      console.log("Loaded data:", data);
      setResult(data);
    } catch (err: any) {
      console.error("Load failed:", err);
      setError("❌ Load failed: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setResult(null);
    setError(null);
  };

  return (
    <div className="fixed bottom-24 right-4 bg-white dark:bg-gray-800 border dark:border-gray-700 rounded-lg shadow-md p-4 text-sm z-50 w-72">
      <h3 className="font-semibold mb-2">🔥 Firestore Smoke Test</h3>

      <div className="flex gap-2 mb-3">
        <button
          onClick={handleSave}
          className="flex-1 px-2 py-1 bg-green-600 text-white rounded hover:bg-green-700"
          disabled={loading}
        >
          Save
        </button>
        <button
          onClick={handleLoad}
          className="flex-1 px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
          disabled={loading}
        >
          Load
        </button>
        <button
          onClick={handleClear}
          className="px-2 py-1 bg-gray-400 text-white rounded hover:bg-gray-500"
          disabled={loading}
        >
          Clear
        </button>
      </div>

      {loading && <div className="text-yellow-500">⏳ Working...</div>}
      {error && <div className="text-red-500">{error}</div>}
      {result && !error && (
        <pre className="bg-gray-100 dark:bg-gray-700 p-2 rounded text-xs overflow-x-auto">
          {typeof result === "string" ? result : JSON.stringify(result, null, 2)}
        </pre>
      )}
    </div>
  );
};

export default SmokeTest;
